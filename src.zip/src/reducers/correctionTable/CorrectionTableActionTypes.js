export const SET_CORRECTION_TABLE = 'SetTable';


