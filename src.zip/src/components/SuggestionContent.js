import React from "react";

const SuggestionContent = ({ paragraphs, selectedNaratives, parasContent }) =>{
  let output = "";
  for (let i = 0; i < parasContent.length; i++) {
    let paragraph = parasContent[i];
    let offset = 0;
    for (let j = 0; j < paragraphs.length; j++) {
      let para = paragraphs[j];
      if (para.ParagraphNum === i + 1 && selectedNaratives.includes(para.id)) {
        let suggestion = para.suggestion;
        if (Array.isArray(suggestion)) {
          suggestion = suggestion.join("");
        }
        let start = para.StartPos + offset;
        let end = para.EndPos + offset;
        paragraph = paragraph.slice(0, start) + suggestion + paragraph.slice(end);
        offset += suggestion.length - (para.EndPos - para.StartPos);
      }
    }
    output += paragraph;
  }
  return <>{output}</>;
}

export default SuggestionContent;
